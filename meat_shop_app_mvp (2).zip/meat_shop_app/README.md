# 🥩 Meat Shop Manager - MVP

**मासु पसल प्रबन्धक** - Complete offline-first mobile app for Nepali meat shop owners.

---

## 📱 Features (MVP)

| Feature | Status | Description |
|---------|--------|-------------|
| 📊 Dashboard | ✅ | Daily income, expense, profit summary + live stock grid |
| 🛒 Sales | ✅ | Record sales with cash/QR/credit, auto stock deduction |
| 📒 Udharo | ✅ | Customer credit ledger, payment tracking, history |
| 📦 Stock | ✅ | Live inventory, low-stock alerts, manual adjustment |
| 💰 Expenses | ✅ | Categorized operational expenses logging |
| 📈 Reports | ✅ | Top selling products, payment breakdown |
| 🌐 Bilingual | ✅ | English ↔ Nepali (नेपाली) toggle |
| 📴 Offline | ✅ | Full SQLite local database, works without internet |

---

## 🚀 How to Test (Step-by-Step)

### Method 1: Run on Emulator (Computer मा Test गर्ने)

#### Step 1: Flutter Install गर्नुहोस्
```bash
# Windows/Mac/Linux मा Flutter SDK download गर्नुहोस्
# https://docs.flutter.dev/get-started/install

# Verify installation
flutter doctor
```

#### Step 2: Project Setup
```bash
# Terminal खोल्नुहोस्
cd meat_shop_app

# Dependencies install गर्नुहोस्
flutter pub get
```

#### Step 3: Emulator Run गर्नुहोस्
```bash
# Android Emulator (Windows/Mac/Linux)
flutter emulators --launch <emulator_id>

# वा connected Android phone
flutter devices
```

#### Step 4: App Run गर्नुहोस्
```bash
flutter run
```

---

### Method 2: Real Android Phone मा Install गर्ने

#### Step 1: APK Build गर्नुहोस्
```bash
cd meat_shop_app

# Release APK build
flutter build apk --release

# Output location:
# build/app/outputs/flutter-apk/app-release.apk
```

#### Step 2: Phone मा Transfer गर्नुहोस्
```bash
# USB cable ले connect गरेर install
flutter install

# वा APK file phone मा copy गर्नुहोस्
# File Manager बाट tap गरेर install
```

#### Step 3: Install गर्नुहोस्
- Phone मा `Settings > Security > Unknown Sources` enable गर्नुहोस्
- APK file tap गरेर Install गर्नुहोस्

---

### Method 3: Play Store को लागि (Production)

#### Step 1: Signing Key बनाउनुहोस्
```bash
# keystore file बनाउनुहोस्
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

#### Step 2: App Bundle (AAB) Build
```bash
flutter build appbundle --release

# Output: build/app/outputs/bundle/release/app-release.aab
```

#### Step 3: Google Play Console मा Upload
- https://play.google.com/console मा जानुहोस्
- New app create गर्नुहोस्
- AAB file upload गर्नुहोस्
- Review पठाउनुहोस्

---

## 🧪 Test Cases (MVP Validation)

### Test 1: Sales Entry
```
1. Dashboard मा "New Sale" button tap गर्नुहोस्
2. Meat Type: Chicken select गर्नुहोस्
3. Quantity: 2.5 KG
4. Rate: 450 per KG
5. Total: Auto-calculate हुनुपर्छ (Rs. 1,125)
6. Payment: Cash select गर्नुहोस्
7. Save गर्नुहोस्
✅ Expected: Stock 25 KG बाट 22.5 KG हुनुपर्छ
```

### Test 2: Udharo (Credit)
```
1. Sales मा जानुहोस्
2. Payment Method: Credit select गर्नुहोस्
3. New Customer: Ram Bahadur
4. Phone: 98XXXXXXXX
5. Sale save गर्नुहोस्
6. Udharo tab मा जानुहोस्
✅ Expected: Ram Bahadur देखिनुपर्छ with outstanding amount
7. "Mark Paid" tap गरेर amount enter गर्नुहोस्
✅ Expected: Outstanding कम हुनुपर्छ
```

### Test 3: Stock Alert
```
1. Stock tab मा जानुहोस्
2. Chicken को stock 3 KG भन्दा कम बनाउनुहोस्
3. Dashboard मा फर्किनुहोस्
✅ Expected: Chicken card मा "LOW" badge देखिनुपर्छ
```

### Test 4: Language Toggle
```
1. Dashboard को top-right मा language icon tap गर्नुहोस्
✅ Expected: सबै text नेपाली मा change हुनुपर्छ
2. फेरि tap गर्नुहोस्
✅ Expected: English मा फर्किनुपर्छ
```

### Test 5: Offline Mode
```
1. Phone को internet बन्द गर्नुहोस्
2. Sales entry गर्नुहोस्
3. Expense add गर्नुहोस्
✅ Expected: सबै काम गर्नुपर्छ (SQLite local मा save हुन्छ)
4. Internet on गर्नुहोस्
✅ Expected: Data sync हुनुपर्छ (future Supabase integration)
```

---

## 📂 Project Structure

```
meat_shop_app/
├── lib/
│   ├── main.dart                    # App entry point + navigation
│   ├── screens/
│   │   ├── dashboard_screen.dart    # Home: summary + stock grid
│   │   ├── sales_screen.dart        # Sales entry form
│   │   ├── udharo_screen.dart       # Credit ledger
│   │   ├── stock_screen.dart        # Inventory management
│   │   ├── expense_screen.dart      # Expense logging
│   │   └── reports_screen.dart      # Analytics + top products
│   ├── services/
│   │   ├── database_service.dart    # SQLite CRUD operations
│   │   └── localization_service.dart # EN/NE translation
│   └── widgets/
│       ├── summary_card.dart        # Financial summary widget
│       └── stock_grid.dart          # Stock grid widget
├── pubspec.yaml                     # Dependencies
└── README.md                        # This file
```

---

## 🔧 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Flutter 3.x (Dart) |
| Local DB | SQLite (sqflite) |
| State | StatefulWidget + FutureBuilder |
| Localization | flutter_localizations |
| Charts | fl_chart (ready for integration) |

---

## 🗺️ Roadmap

### Phase 1: MVP ✅ (Current)
- [x] Offline SQLite database
- [x] All core features
- [x] English/Nepali bilingual

### Phase 2: Production
- [ ] Supabase cloud sync
- [ ] PDF report export
- [ ] Push notifications
- [ ] Nepali date (BS calendar)
- [ ] Biometric lock

### Phase 3: Scale
- [ ] Multi-shop support
- [ ] QR payment integration (eSewa/Khalti)
- [ ] Voice input (Nepali)
- [ ] WhatsApp payment reminders

---

## 🆘 Troubleshooting

### Error: `flutter: command not found`
```bash
# Flutter PATH add गर्नुहोस्
export PATH="$PATH:/path/to/flutter/bin"
```

### Error: `Gradle build failed`
```bash
# Clean build
flutter clean
flutter pub get
flutter build apk
```

### Error: `sqflite not found`
```bash
flutter pub add sqflite path
flutter pub get
```

---

## 👨‍💻 Developer

Built for Nepali meat shop owners 🇳🇵

**License:** MIT
**Version:** 1.0.0 MVP
