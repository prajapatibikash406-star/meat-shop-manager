# 🚀 GitHub Actions Setup Guide - APK Auto-Build
# GitHub Actions सेटअप गाइड - APK अटो-बिल्ड

================================================================================
PART 1: GitHub Repository Setup (५ मिनेट)
================================================================================

## Step 1: GitHub Account बनाउनुहोस्
```
https://github.com/signup
Email, password, username राख्नुहोस्
Verify email
```

## Step 2: New Repository बनाउनुहोस्
```
https://github.com/new

Repository name: meat-shop-manager
Description: Meat Shop Management App for Nepali Butchers
Visibility: Public (वा Private)
☑ Add a README file
☑ Add .gitignore (Dart/Flutter)
Create repository
```

## Step 3: Project Upload गर्नुहोस्

### Option A: GitHub Web Interface (सजिलो)
```
1. Repository खोल्नुहोस्
2. "Add file" > "Upload files"
3. meat_shop_app_mvp.zip upload गर्नुहोस्
4. Extract गर्नुहोस् (वा local मा extract गरेर files upload गर्नुहोस्)
```

### Option B: Command Line (Git)
```bash
# Terminal खोल्नुहोस्
cd meat_shop_app

# Git initialize
git init

# All files add गर्नुहोस्
git add .

# Commit
git commit -m "Initial MVP release"

# Remote add
git remote add origin https://github.com/YOUR_USERNAME/meat-shop-manager.git

# Push
git branch -M main
git push -u origin main
```

================================================================================
PART 2: GitHub Actions Enable गर्ने (२ मिनेट)
================================================================================

## Step 4: Workflow File Verify गर्नुहोस्

Project मा यो file हुनुपर्छ:
```
.github/
└── workflows/
    └── build.yml
```

## Step 5: Actions Enable गर्नुहोस्
```
1. Repository मा जानुहोस्
2. "Actions" tab मा जानुहोस्
3. "I understand my workflows, go ahead and enable" थिच्नुहोस्
```

## Step 6: Workflow Run गर्नुहोस्
```
1. "Actions" tab मा जानुहोस्
2. "Build Meat Shop APK" workflow देख्नुहुन्छ
3. "Run workflow" > "Run workflow" थिच्नुहोस्
4. ५-१० मिनेट पर्खनुहोस्
```

================================================================================
PART 3: APK Download गर्ने (१ मिनेट)
================================================================================

## Method 1: Artifacts बाट (Development Builds)
```
1. Actions tab मा जानुहोस्
2. Latest successful run खोल्नुहोस् (green checkmark)
3. तल "Artifacts" section मा जानुहोस्
4. "meat-shop-release-apk" download गर्नुहोस्
5. ZIP extract गर्नुहोस्
6. app-release.apk तपाईंको phone मा पठाउनुहोस्
```

## Method 2: Releases बाट (Production Builds)
```
1. Repository को "Releases" section मा जानुहोस्
2. Latest release खोल्नुहोस्
3. "Assets" section मा जानुहोस्
4. app-release.apk download गर्नुहोस्
```

================================================================================
PART 4: Phone मा Install गर्ने (२ मिनेट)
================================================================================

## Step 7: Phone Settings
```
Settings > Security > Unknown Sources
☑ Allow installation from unknown sources
```

## Step 8: APK Install
```
1. File Manager खोल्नुहोस्
2. Downloads folder मा जानुहोस्
3. app-release.apk tap गर्नुहोस्
4. "Install" थिच्नुहोस्
5. "Open" थिच्नुहोस्
```

## Step 9: App Use गर्नुहोस्! 🎉
```
🥩 Meat Shop Manager खुल्छ
Dashboard मा आजको summary देख्छ
बिक्री, उधारो, स्टक सबै manage गर्न सकिन्छ
```

================================================================================
PART 5: Auto-Build Setup (Future Updates को लागि)
================================================================================

## Automatic Build on Push
```
जब तपाईं code push गर्नुहुन्छ:
  ↓
GitHub Actions automatically trigger हुन्छ
  ↓
APK build हुन्छ
  ↓
Artifact मा upload हुन्छ
  ↓
Release मा publish हुन्छ (main branch मा मात्र)
```

## Manual Trigger
```
Actions tab > Build Meat Shop APK > Run workflow
कुनै पनि समयमा manually build गर्न सकिन्छ
```

================================================================================
PART 6: Troubleshooting (समस्या समाधान)
================================================================================

## Problem 1: Build Fails
```
❌ Error: "flutter: command not found"
✅ Solution: Workflow file मा flutter-action सही छ कि check गर्नुहोस्

❌ Error: "Gradle build failed"
✅ Solution: Repository मा android/ folder छ कि check गर्नुहोस्

❌ Error: "pubspec.yaml not found"
✅ Solution: Project root मा pubspec.yaml हुनुपर्छ
```

## Problem 2: APK Download गर्न मिल्दैन
```
❌ "Artifacts expired"
✅ Solution: Retention period 90 days, फेरि build गर्नुहोस्

❌ "Release not created"
✅ Solution: Main branch मा push गर्नुपर्छ, अरु branch मा हुँदैन
```

## Problem 3: Install हुँदैन
```
❌ "App not installed"
✅ Solution: पुरानो version uninstall गर्नुहोस्

❌ "Parse error"
✅ Solution: Android 5.0+ चाहिन्छ, purano phone मा काम गर्दैन

❌ "Blocked by Play Protect"
✅ Solution: "Install anyway" थिच्नुहोस्
```

================================================================================
PART 7: Video Tutorial (Step-by-Step)
================================================================================

```
Step 1: GitHub Account (0:00 - 1:00)
  ↳ signup गर्नुहोस्

Step 2: New Repository (1:00 - 2:00)
  ↳ meat-shop-manager नाम राख्नुहोस्

Step 3: Upload Files (2:00 - 4:00)
  ↳ project files upload गर्नुहोस्

Step 4: Enable Actions (4:00 - 5:00)
  ↳ Actions tab मा जानुहोस्

Step 5: Run Workflow (5:00 - 6:00)
  ↳ Build trigger गर्नुहोस्

Step 6: Wait & Download (6:00 - 15:00)
  ↳ 5-10 minutes wait गर्नुहोस्
  ↳ APK download गर्नुहोस्

Step 7: Phone Install (15:00 - 17:00)
  ↳ APK install गर्नुहोस्

Step 8: Enjoy! (17:00+)
  ↳ App use गर्नुहोस्
```

================================================================================
PART 8: Quick Commands Reference
================================================================================

## Git Commands
```bash
git clone https://github.com/YOUR_USERNAME/meat-shop-manager.git
git add .
git commit -m "Update"
git push origin main
```

## Flutter Commands (Local)
```bash
flutter doctor
flutter pub get
flutter build apk --release
flutter build appbundle --release
```

## GitHub CLI (Optional)
```bash
gh repo create meat-shop-manager --public
gh workflow run build.yml
gh run list
gh release list
```

================================================================================
END OF GUIDE
================================================================================
