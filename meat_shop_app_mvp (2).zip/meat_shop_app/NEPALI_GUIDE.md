# 🇳🇵 मासु पसल एप - तुरुन्तै सुरु गर्ने तरिका

## तपाईंको फोन मा एप कसरी राख्ने?

### विकल्प १: कम्प्युटर बाट (Developer ले गर्ने)

```bash
# १. Flutter Install गर्नुहोस्
https://docs.flutter.dev/get-started/install

# २. यो folder मा जानुहोस्
cd meat_shop_app

# ३. Dependencies Install
flutter pub get

# ४. APK Build (Android को लागि)
flutter build apk --release

# ५. APK तपाईंको फोन मा पठाउनुहोस्
# USB cable वा Bluetooth बाट
```

### विकल्प २: सिधै फोन मा Install (User ले गर्ने)

**Step 1:** `app-release.apk` file download गर्नुहोस्

**Step 2:** Phone मा Settings खोल्नुहोस्
- `Security` > `Unknown Sources` ON गर्नुहोस्

**Step 3:** APK file tap गरेर Install गर्नुहोस्

**Step 4:** App खोल्नुहोस् र प्रयोग गर्नुहोस्! 🎉

---

## 🧪 Test कसरी गर्ने?

### Test १: बिक्री दर्ता गर्ने
1. Dashboard मा "नयाँ बिक्री" button
2. मासुको प्रकार: कुखुरा
3. परिमाण: २.५ केजी
4. दर: ४५० प्रति केजी
5. भुक्तानी: नगद
6. सुरक्षित गर्नुहोस्
✅ स्टक २५ केजी बाट २२.५ केजी हुनुपर्छ

### Test २: उधारो (Credit)
1. बिक्री मा जानुहोस्
2. भुक्तानी विधि: उधारो
3. नयाँ ग्राहक: राम बहादुर
4. फोन: ९८XXXXXXXX
5. सुरक्षित गर्नुहोस्
6. उधारो tab मा जानुहोस्
✅ राम बहादुर देखिनुपर्छ

### Test ३: भाषा Switch
1. Dashboard को माथि language icon
2. English ↔ नेपाली
✅ सबै text change हुनुपर्छ

---

## 📞 Support

केही समस्या भएमा:
1. App uninstall गरेर फेरि install गर्नुहोस्
2. Phone restart गर्नुहोस्
3. Developer लाई सम्पर्क गर्नुहोस्
