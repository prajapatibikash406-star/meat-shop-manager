import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:async';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('meat_shop.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future<void> init() async {
    await database;
    await _seedProducts();
  }

  Future _createDB(Database db, int version) async {
    const productTable = """
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name_en TEXT NOT NULL,
        name_np TEXT NOT NULL,
        current_stock_kg REAL DEFAULT 0,
        min_stock_alert_kg REAL DEFAULT 3,
        avg_buying_rate REAL DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    """;
    await db.execute(productTable);

    const salesTable = """
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        quantity_kg REAL NOT NULL,
        rate_per_kg REAL NOT NULL,
        total_amount REAL NOT NULL,
        payment_method TEXT NOT NULL,
        customer_id INTEGER,
        customer_name TEXT,
        customer_phone TEXT,
        sale_date TEXT NOT NULL,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id)
      )
    """;
    await db.execute(salesTable);

    const customersTable = """
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        total_credit REAL DEFAULT 0,
        total_paid REAL DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    """;
    await db.execute(customersTable);

    const creditPaymentsTable = """
      CREATE TABLE credit_payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        payment_date TEXT NOT NULL,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
      )
    """;
    await db.execute(creditPaymentsTable);

    const purchasesTable = """
      CREATE TABLE purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        purchase_type TEXT NOT NULL,
        quantity_kg REAL NOT NULL,
        rate_per_kg REAL NOT NULL,
        total_cost REAL NOT NULL,
        supplier_name TEXT,
        purchase_date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id)
      )
    """;
    await db.execute(purchasesTable);

    const expensesTable = """
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        expense_date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    """;
    await db.execute(expensesTable);

    const wastageTable = """
      CREATE TABLE wastage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        wastage_type TEXT NOT NULL,
        quantity_kg REAL NOT NULL,
        financial_loss REAL NOT NULL,
        reason TEXT,
        date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id)
      )
    """;
    await db.execute(wastageTable);
  }

  Future<void> _seedProducts() async {
    final db = await database;
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products'));
    if (count == 0) {
      final products = [
        {'name_en': 'Chicken', 'name_np': 'कुखुरा', 'current_stock_kg': 25.0},
        {'name_en': 'Mutton', 'name_np': 'खसी', 'current_stock_kg': 15.0},
        {'name_en': 'Buff', 'name_np': 'भैंसी', 'current_stock_kg': 20.0},
        {'name_en': 'Pork', 'name_np': 'सुँगुर', 'current_stock_kg': 10.0},
        {'name_en': 'Fish', 'name_np': 'माछा', 'current_stock_kg': 8.0},
      ];
      for (var p in products) {
        await db.insert('products', p);
      }
    }
  }

  // PRODUCTS
  Future<List<Map<String, dynamic>>> getProducts() async {
    final db = await database;
    return await db.query('products', where: 'is_active = ?', whereArgs: [1], orderBy: 'name_en');
  }

  Future<Map<String, dynamic>?> getProduct(int id) async {
    final db = await database;
    final results = await db.query('products', where: 'id = ?', whereArgs: [id]);
    return results.isNotEmpty ? results.first : null;
  }

  Future<void> updateProductStock(int productId, double newStock) async {
    final db = await database;
    await db.update('products', {'current_stock_kg': newStock}, where: 'id = ?', whereArgs: [productId]);
  }

  // SALES
  Future<int> addSale(Map<String, dynamic> sale) async {
    final db = await database;
    final id = await db.insert('sales', sale);

    final product = await getProduct(sale['product_id']);
    if (product != null) {
      final newStock = (product['current_stock_kg'] as double) - (sale['quantity_kg'] as double);
      await updateProductStock(sale['product_id'], newStock);
    }

    if (sale['payment_method'] == 'credit' && sale['customer_id'] != null) {
      await db.rawUpdate(
        'UPDATE customers SET total_credit = total_credit + ? WHERE id = ?',
        [sale['total_amount'], sale['customer_id']],
      );
    }

    return id;
  }

  Future<List<Map<String, dynamic>>> getSales({String? date}) async {
    final db = await database;
    if (date != null) {
      return await db.query('sales', where: 'sale_date = ?', whereArgs: [date], orderBy: 'created_at DESC');
    }
    return await db.query('sales', orderBy: 'created_at DESC', limit: 100);
  }

  Future<double> getTotalSalesAmount({String? date, String? paymentMethod}) async {
    final db = await database;
    String query = 'SELECT SUM(total_amount) as total FROM sales';
    List<dynamic> args = [];

    if (date != null) {
      query += ' WHERE sale_date = ?';
      args.add(date);
    }
    if (paymentMethod != null) {
      query += date != null ? ' AND payment_method = ?' : ' WHERE payment_method = ?';
      args.add(paymentMethod);
    }

    final result = await db.rawQuery(query, args);
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  // CUSTOMERS
  Future<int> addCustomer(Map<String, dynamic> customer) async {
    final db = await database;
    return await db.insert('customers', customer);
  }

  Future<List<Map<String, dynamic>>> getCustomers() async {
    final db = await database;
    return await db.query('customers', where: 'is_active = ?', whereArgs: [1], orderBy: 'name');
  }

  Future<Map<String, dynamic>?> getCustomer(int id) async {
    final db = await database;
    final results = await db.query('customers', where: 'id = ?', whereArgs: [id]);
    return results.isNotEmpty ? results.first : null;
  }

  Future<void> recordPayment(int customerId, double amount, {String? notes}) async {
    final db = await database;
    await db.insert('credit_payments', {
      'customer_id': customerId,
      'amount': amount,
      'payment_date': DateTime.now().toIso8601String().split('T')[0],
      'notes': notes,
    });

    await db.rawUpdate(
      'UPDATE customers SET total_paid = total_paid + ? WHERE id = ?',
      [amount, customerId],
    );
  }

  Future<List<Map<String, dynamic>>> getCustomerPayments(int customerId) async {
    final db = await database;
    return await db.query('credit_payments', 
      where: 'customer_id = ?', 
      whereArgs: [customerId],
      orderBy: 'payment_date DESC',
    );
  }

  // PURCHASES
  Future<int> addPurchase(Map<String, dynamic> purchase) async {
    final db = await database;
    final id = await db.insert('purchases', purchase);

    final product = await getProduct(purchase['product_id']);
    if (product != null) {
      final newStock = (product['current_stock_kg'] as double) + (purchase['quantity_kg'] as double);
      await updateProductStock(purchase['product_id'], newStock);
    }

    return id;
  }

  Future<double> getTotalPurchasesCost({String? date}) async {
    final db = await database;
    String query = 'SELECT SUM(total_cost) as total FROM purchases';
    List<dynamic> args = [];

    if (date != null) {
      query += ' WHERE purchase_date = ?';
      args.add(date);
    }

    final result = await db.rawQuery(query, args);
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  // EXPENSES
  Future<int> addExpense(Map<String, dynamic> expense) async {
    final db = await database;
    return await db.insert('expenses', expense);
  }

  Future<List<Map<String, dynamic>>> getExpenses({String? date}) async {
    final db = await database;
    if (date != null) {
      return await db.query('expenses', where: 'expense_date = ?', whereArgs: [date], orderBy: 'created_at DESC');
    }
    return await db.query('expenses', orderBy: 'created_at DESC', limit: 100);
  }

  Future<double> getTotalExpenses({String? date}) async {
    final db = await database;
    String query = 'SELECT SUM(amount) as total FROM expenses';
    List<dynamic> args = [];

    if (date != null) {
      query += ' WHERE expense_date = ?';
      args.add(date);
    }

    final result = await db.rawQuery(query, args);
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  // WASTAGE
  Future<int> addWastage(Map<String, dynamic> wastage) async {
    final db = await database;
    final id = await db.insert('wastage', wastage);

    final product = await getProduct(wastage['product_id']);
    if (product != null) {
      final newStock = (product['current_stock_kg'] as double) - (wastage['quantity_kg'] as double);
      await updateProductStock(wastage['product_id'], newStock);
    }

    return id;
  }

  Future<double> getTotalWastageLoss({String? date}) async {
    final db = await database;
    String query = 'SELECT SUM(financial_loss) as total FROM wastage';
    List<dynamic> args = [];

    if (date != null) {
      query += ' WHERE date = ?';
      args.add(date);
    }

    final result = await db.rawQuery(query, args);
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  // ANALYTICS
  Future<Map<String, dynamic>> getDashboardSummary(String date) async {
    final income = await getTotalSalesAmount(date: date);
    final purchaseCost = await getTotalPurchasesCost(date: date);
    final expenses = await getTotalExpenses(date: date);
    final wastageLoss = await getTotalWastageLoss(date: date);

    final totalExpense = purchaseCost + expenses + wastageLoss;
    final netProfit = income - totalExpense;

    return {
      'income': income,
      'expenses': totalExpense,
      'netProfit': netProfit,
      'purchaseCost': purchaseCost,
      'operationalExpenses': expenses,
      'wastageLoss': wastageLoss,
    };
  }

  Future<List<Map<String, dynamic>>> getTopSellingProducts({int limit = 5, String? startDate, String? endDate}) async {
    final db = await database;
    String query = """
      SELECT p.name_en, p.name_np, SUM(s.quantity_kg) as total_qty, SUM(s.total_amount) as total_amount
      FROM sales s
      JOIN products p ON s.product_id = p.id
    """;

    List<dynamic> args = [];
    if (startDate != null && endDate != null) {
      query += ' WHERE s.sale_date BETWEEN ? AND ?';
      args.addAll([startDate, endDate]);
    }

    query += ' GROUP BY s.product_id ORDER BY total_qty DESC LIMIT ?';
    args.add(limit);

    return await db.rawQuery(query, args);
  }

  Future<Map<String, double>> getSalesByPaymentMethod(String date) async {
    final db = await database;
    final results = await db.rawQuery(
      'SELECT payment_method, SUM(total_amount) as total FROM sales WHERE sale_date = ? GROUP BY payment_method',
      [date],
    );

    final Map<String, double> breakdown = {};
    for (var row in results) {
      breakdown[row['payment_method'] as String] = (row['total'] as num).toDouble();
    }
    return breakdown;
  }

  Future<void> close() async {
    final db = await database;
    await db.close();
  }
}
