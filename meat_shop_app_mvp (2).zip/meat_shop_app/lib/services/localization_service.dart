import 'package:flutter/material.dart';

class LocalizationService {
  static final LocaleNotifier localeNotifier = LocaleNotifier();

  static Locale get currentLocale => localeNotifier.value;

  static void toggleLanguage() {
    if (localeNotifier.value.languageCode == 'en') {
      localeNotifier.value = const Locale('ne', 'NP');
    } else {
      localeNotifier.value = const Locale('en', 'US');
    }
  }

  static String translate(String key) {
    return _translations[currentLocale.languageCode]?[key] ?? key;
  }

  static String formatCurrency(double amount) {
    final symbol = currentLocale.languageCode == 'ne' ? 'रु ' : 'Rs. ';
    return '$symbol${amount.toStringAsFixed(0)}';
  }

  static String formatNumber(double number) {
    if (currentLocale.languageCode == 'ne') {
      return _toNepaliNumerals(number.toStringAsFixed(1));
    }
    return number.toStringAsFixed(1);
  }

  static String _toNepaliNumerals(String input) {
    const nepaliDigits = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
    return input.split('').map((c) {
      if (c == '.') return '.';
      final digit = int.tryParse(c);
      return digit != null ? nepaliDigits[digit] : c;
    }).join();
  }

  static final Map<String, Map<String, String>> _translations = {
    'en': {
      'app_title': 'Meat Shop Manager',
      'dashboard': 'Dashboard',
      'sales': 'Sales',
      'udharo': 'Udharo',
      'stock': 'Stock',
      'reports': 'Reports',
      'expenses': 'Expenses',
      'today_income': "Today's Income",
      'today_expense': "Today's Expense",
      'net_profit': 'Net Profit',
      'live_stock': 'Live Stock',
      'new_sale': 'New Sale',
      'meat_type': 'Meat Type',
      'quantity_kg': 'Quantity (KG)',
      'rate_per_kg': 'Rate per KG',
      'total_amount': 'Total Amount',
      'payment_method': 'Payment Method',
      'cash': 'Cash',
      'qr_code': 'QR Code',
      'credit': 'Credit (Udharo)',
      'customer_name': 'Customer Name',
      'customer_phone': 'Customer Phone',
      'save_sale': 'Save Sale',
      'add_expense': 'Add Expense',
      'expense_category': 'Category',
      'amount': 'Amount',
      'description': 'Description',
      'rent': 'Rent',
      'electricity': 'Electricity',
      'salary': 'Staff Salary',
      'transportation': 'Transportation',
      'feed_supplies': 'Feed/Supplies',
      'miscellaneous': 'Miscellaneous',
      'purchase': 'Purchase',
      'live_animal': 'Live Animal',
      'ready_meat': 'Ready Meat',
      'supplier': 'Supplier',
      'wastage': 'Wastage',
      'wastage_type': 'Wastage Type',
      'bone_waste': 'Bone Waste',
      'spoilage': 'Spoilage',
      'cutting_loss': 'Cutting Loss',
      'reason': 'Reason',
      'outstanding': 'Outstanding',
      'mark_paid': 'Mark Paid',
      'payment_history': 'Payment History',
      'add_customer': 'Add Customer',
      'search_customer': 'Search customer...',
      'no_customers': 'No customers found',
      'daily': 'Daily',
      'weekly': 'Weekly',
      'monthly': 'Monthly',
      'revenue': 'Revenue',
      'top_selling': 'Top Selling',
      'low_stock_alert': 'Low Stock Alert',
      'kg': 'KG',
      'cancel': 'Cancel',
      'save': 'Save',
      'delete': 'Delete',
      'edit': 'Edit',
      'success': 'Success',
      'error': 'Error',
      'required_field': 'This field is required',
      'invalid_phone': 'Invalid phone number',
      'insufficient_stock': 'Insufficient stock available',
      'sale_saved': 'Sale saved successfully',
      'expense_saved': 'Expense saved successfully',
      'purchase_saved': 'Purchase saved and stock updated',
      'wastage_logged': 'Wastage logged and stock updated',
      'payment_recorded': 'Payment recorded successfully',
      'customer_added': 'Customer added successfully',
      'stock_updated': 'Stock updated',
      'confirm_delete': 'Are you sure you want to delete?',
      'todays_summary': "Today's Summary",
      'financial_health': 'Financial Health',
      'quick_actions': 'Quick Actions',
      'record_sale': 'Record Sale',
      'add_purchase': 'Add Purchase',
      'log_wastage': 'Log Wastage',
      'view_reports': 'View Reports',
      'all_time': 'All Time',
      'total_sales': 'Total Sales',
      'total_purchases': 'Total Purchases',
      'total_wastage': 'Total Wastage',
      'profit_margin': 'Profit Margin',
      'sync_status': 'Sync Status',
      'synced': 'Synced',
      'pending': 'Pending Sync',
      'offline_mode': 'Offline Mode',
      'language': 'Language',
      'english': 'English',
      'nepali': 'Nepali',
    },
    'ne': {
      'app_title': 'मासु पसल प्रबन्धक',
      'dashboard': 'ड्यासबोर्ड',
      'sales': 'बिक्री',
      'udharo': 'उधारो',
      'stock': 'स्टक',
      'reports': 'रिपोर्ट',
      'expenses': 'खर्च',
      'today_income': 'आजको आम्दानी',
      'today_expense': 'आजको खर्च',
      'net_profit': 'नाफा',
      'live_stock': 'जीवित स्टक',
      'new_sale': 'नयाँ बिक्री',
      'meat_type': 'मासुको प्रकार',
      'quantity_kg': 'परिमाण (केजी)',
      'rate_per_kg': 'प्रति केजी दर',
      'total_amount': 'कुल रकम',
      'payment_method': 'भुक्तानी विधि',
      'cash': 'नगद',
      'qr_code': 'क्युआर कोड',
      'credit': 'उधारो',
      'customer_name': 'ग्राहकको नाम',
      'customer_phone': 'ग्राहकको फोन',
      'save_sale': 'बिक्री सुरक्षित गर्नुहोस्',
      'add_expense': 'खर्च थप्नुहोस्',
      'expense_category': 'श्रेणी',
      'amount': 'रकम',
      'description': 'विवरण',
      'rent': 'भाडा',
      'electricity': 'बिजुली',
      'salary': 'कर्मचारी तलब',
      'transportation': 'यातायात',
      'feed_supplies': 'दाना/सामग्री',
      'miscellaneous': 'विविध',
      'purchase': 'खरिद',
      'live_animal': 'जीवित जनावर',
      'ready_meat': 'तयार मासु',
      'supplier': 'आपूर्तिकर्ता',
      'wastage': 'बर्बादी',
      'wastage_type': 'बर्बादीको प्रकार',
      'bone_waste': 'हड्डी फोहोर',
      'spoilage': 'खराब हुनु',
      'cutting_loss': 'काट्ने क्षति',
      'reason': 'कारण',
      'outstanding': 'बाँकी रकम',
      'mark_paid': 'तिरेको चिन्ह लगाउनुहोस्',
      'payment_history': 'भुक्तानी इतिहास',
      'add_customer': 'ग्राहक थप्नुहोस्',
      'search_customer': 'ग्राहक खोज्नुहोस्...',
      'no_customers': 'कुनै ग्राहक भेटिएन',
      'daily': 'दैनिक',
      'weekly': 'साप्ताहिक',
      'monthly': 'मासिक',
      'revenue': 'आम्दानी',
      'top_selling': 'सबैभन्दा बढी बिक्री',
      'low_stock_alert': 'कम स्टक अलर्ट',
      'kg': 'केजी',
      'cancel': 'रद्द गर्नुहोस्',
      'save': 'सुरक्षित गर्नुहोस्',
      'delete': 'मेटाउनुहोस्',
      'edit': 'सम्पादन गर्नुहोस्',
      'success': 'सफल',
      'error': 'त्रुटि',
      'required_field': 'यो फिल्ड आवश्यक छ',
      'invalid_phone': 'अमान्य फोन नम्बर',
      'insufficient_stock': 'पर्याप्त स्टक छैन',
      'sale_saved': 'बिक्री सफलतापूर्वक सुरक्षित भयो',
      'expense_saved': 'खर्च सफलतापूर्वक सुरक्षित भयो',
      'purchase_saved': 'खरिद सुरक्षित र स्टक अद्यावधिक भयो',
      'wastage_logged': 'बर्बादी दर्ता र स्टक अद्यावधिक भयो',
      'payment_recorded': 'भुक्तानी सफलतापूर्वक दर्ता भयो',
      'customer_added': 'ग्राहक सफलतापूर्वक थपियो',
      'stock_updated': 'स्टक अद्यावधिक भयो',
      'confirm_delete': 'के तपाईं मेटाउन निश्चित हुनुहुन्छ?',
      'todays_summary': 'आजको सारांश',
      'financial_health': 'आर्थिक अवस्था',
      'quick_actions': 'द्रुत कार्यहरू',
      'record_sale': 'बिक्री दर्ता गर्नुहोस्',
      'add_purchase': 'खरिद थप्नुहोस्',
      'log_wastage': 'बर्बादी दर्ता गर्नुहोस्',
      'view_reports': 'रिपोर्ट हेर्नुहोस्',
      'all_time': 'सबै समय',
      'total_sales': 'कुल बिक्री',
      'total_purchases': 'कुल खरिद',
      'total_wastage': 'कुल बर्बादी',
      'profit_margin': 'नाफा मार्जिन',
      'sync_status': 'सिंक स्थिति',
      'synced': 'सिंक भयो',
      'pending': 'सिंक हुन बाँकी',
      'offline_mode': 'अफलाइन मोड',
      'language': 'भाषा',
      'english': 'English',
      'nepali': 'नेपाली',
    },
  };
}

class LocaleNotifier extends ValueNotifier<Locale> {
  LocaleNotifier() : super(const Locale('en', 'US'));
}
