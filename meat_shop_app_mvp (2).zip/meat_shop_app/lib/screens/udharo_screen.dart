import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';

class UdharoScreen extends StatefulWidget {
  const UdharoScreen({super.key});

  @override
  State<UdharoScreen> createState() => _UdharoScreenState();
}

class _UdharoScreenState extends State<UdharoScreen> {
  List<Map<String, dynamic>> _customers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final customers = await DatabaseService.instance.getCustomers();
    if (mounted) {
      setState(() {
        _customers = customers;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('udharo')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Summary Header
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.orange.shade600, Colors.orange.shade800],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Total Outstanding',
                        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        LocalizationService.formatCurrency(
                          _customers.fold<double>(0, (sum, c) => sum + ((c['total_credit'] ?? 0) - (c['total_paid'] ?? 0))),
                        ),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_customers.length} ${loc('udharo')} ${loc('customers')}',
                        style: TextStyle(color: Colors.white.withOpacity(0.7)),
                      ),
                    ],
                  ),
                ),

                // Customer List
                Expanded(
                  child: _customers.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.people_outline, size: 64, color: Colors.grey.shade400),
                              const SizedBox(height: 16),
                              Text(
                                loc('no_customers'),
                                style: TextStyle(color: Colors.grey.shade500, fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _customers.length,
                          itemBuilder: (context, index) {
                            final customer = _customers[index];
                            final outstanding = (customer['total_credit'] ?? 0.0) - (customer['total_paid'] ?? 0.0);

                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: InkWell(
                                onTap: () => _showCustomerDetail(customer),
                                borderRadius: BorderRadius.circular(12),
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          CircleAvatar(
                                            backgroundColor: outstanding > 0 
                                                ? Colors.orange.withOpacity(0.2) 
                                                : const Color(0xFF138808).withOpacity(0.2),
                                            child: Icon(
                                              Icons.person,
                                              color: outstanding > 0 ? Colors.orange : const Color(0xFF138808),
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  customer['name'],
                                                  style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                if (customer['phone'] != null)
                                                  Text(
                                                    customer['phone'],
                                                    style: TextStyle(
                                                      color: Colors.grey.shade600,
                                                      fontSize: 13,
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Text(
                                                LocalizationService.formatCurrency(outstanding),
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                  color: outstanding > 0 ? Colors.orange.shade800 : const Color(0xFF138808),
                                                ),
                                              ),
                                              Text(
                                                loc('outstanding'),
                                                style: TextStyle(
                                                  fontSize: 11,
                                                  color: Colors.grey.shade500,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      if (outstanding > 0) ...[
                                        const SizedBox(height: 12),
                                        const Divider(height: 1),
                                        const SizedBox(height: 12),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: OutlinedButton.icon(
                                                onPressed: () => _showPaymentDialog(customer),
                                                icon: const Icon(Icons.check_circle, size: 18),
                                                label: Text(loc('mark_paid')),
                                                style: OutlinedButton.styleFrom(
                                                  foregroundColor: const Color(0xFF138808),
                                                  side: const BorderSide(color: Color(0xFF138808)),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: OutlinedButton.icon(
                                                onPressed: () => _showCustomerDetail(customer),
                                                icon: const Icon(Icons.history, size: 18),
                                                label: Text(loc('payment_history')),
                                                style: OutlinedButton.styleFrom(
                                                  foregroundColor: const Color(0xFFC41E3A),
                                                  side: const BorderSide(color: Color(0xFFC41E3A)),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddCustomerDialog,
        backgroundColor: const Color(0xFFC41E3A),
        icon: const Icon(Icons.person_add),
        label: Text(loc('add_customer')),
      ),
    );
  }

  void _showAddCustomerDialog() {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    final loc = LocalizationService.translate;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(loc('add_customer')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: loc('customer_name'),
                prefixIcon: const Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: loc('customer_phone'),
                prefixIcon: const Icon(Icons.phone),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.isEmpty) return;

              await DatabaseService.instance.addCustomer({
                'name': nameController.text,
                'phone': phoneController.text.isEmpty ? null : phoneController.text,
              });

              Navigator.pop(context);
              _loadCustomers();

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(loc('customer_added'))),
              );
            },
            child: Text(loc('save')),
          ),
        ],
      ),
    );
  }

  void _showPaymentDialog(Map<String, dynamic> customer) {
    final amountController = TextEditingController();
    final loc = LocalizationService.translate;
    final outstanding = (customer['total_credit'] ?? 0.0) - (customer['total_paid'] ?? 0.0);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${loc('mark_paid')} - ${customer['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${loc('outstanding')}: ${LocalizationService.formatCurrency(outstanding)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: loc('amount'),
                prefixIcon: const Icon(Icons.attach_money),
              ),
              autofocus: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              final amount = double.tryParse(amountController.text) ?? 0;
              if (amount <= 0) return;

              await DatabaseService.instance.recordPayment(
                customer['id'],
                amount,
              );

              Navigator.pop(context);
              _loadCustomers();

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(loc('payment_recorded')),
                  backgroundColor: const Color(0xFF138808),
                ),
              );
            },
            child: Text(loc('save')),
          ),
        ],
      ),
    );
  }

  void _showCustomerDetail(Map<String, dynamic> customer) async {
    final payments = await DatabaseService.instance.getCustomerPayments(customer['id']);
    final loc = LocalizationService.translate;

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) {
          return Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: const Color(0xFFC41E3A).withOpacity(0.2),
                      child: const Icon(Icons.person, size: 30, color: Color(0xFFC41E3A)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            customer['name'],
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                          ),
                          if (customer['phone'] != null)
                            Text(
                              customer['phone'],
                              style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF8F0),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatColumn('Total Credit', customer['total_credit'] ?? 0, Colors.orange),
                      Container(height: 40, width: 1, color: Colors.grey.shade300),
                      _buildStatColumn('Total Paid', customer['total_paid'] ?? 0, const Color(0xFF138808)),
                      Container(height: 40, width: 1, color: Colors.grey.shade300),
                      _buildStatColumn('Outstanding', (customer['total_credit'] ?? 0) - (customer['total_paid'] ?? 0), const Color(0xFFDC2626)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  loc('payment_history'),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: payments.isEmpty
                      ? Center(
                          child: Text(
                            'No payment history',
                            style: TextStyle(color: Colors.grey.shade500),
                          ),
                        )
                      : ListView.builder(
                          controller: scrollController,
                          itemCount: payments.length,
                          itemBuilder: (context, index) {
                            final payment = payments[index];
                            return ListTile(
                              leading: const CircleAvatar(
                                backgroundColor: Color(0xFF138808),
                                child: Icon(Icons.check, color: Colors.white, size: 18),
                              ),
                              title: Text(
                                LocalizationService.formatCurrency(payment['amount']),
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(payment['payment_date'] ?? ''),
                              trailing: payment['notes'] != null
                                  ? Icon(Icons.note, color: Colors.grey.shade400)
                                  : null,
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatColumn(String label, double amount, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
        ),
        const SizedBox(height: 4),
        Text(
          LocalizationService.formatCurrency(amount),
          style: TextStyle(
            color: color,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
