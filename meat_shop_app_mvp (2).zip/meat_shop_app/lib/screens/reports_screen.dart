import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String _period = 'daily';
  Map<String, dynamic> _summary = {};
  List<Map<String, dynamic>> _topProducts = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final today = DateTime.now().toIso8601String().split('T')[0];
    final weekAgo = DateTime.now().subtract(const Duration(days: 7)).toIso8601String().split('T')[0];

    final summary = await DatabaseService.instance.getDashboardSummary(today);
    final topProducts = await DatabaseService.instance.getTopSellingProducts(
      limit: 5,
      startDate: weekAgo,
      endDate: today,
    );

    if (mounted) {
      setState(() {
        _summary = summary;
        _topProducts = topProducts;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('reports')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<String>(
                    segments: [
                      ButtonSegment(value: 'daily', label: Text(loc('daily'))),
                      ButtonSegment(value: 'weekly', label: Text(loc('weekly'))),
                      ButtonSegment(value: 'monthly', label: Text(loc('monthly'))),
                    ],
                    selected: {_period},
                    onSelectionChanged: (set) {
                      setState(() => _period = set.first);
                      _loadData();
                    },
                  ),
                  const SizedBox(height: 20),

                  Row(
                    children: [
                      Expanded(
                        child: _ReportCard(
                          title: loc('total_sales'),
                          amount: _summary['income'] ?? 0,
                          color: const Color(0xFF138808),
                          icon: Icons.trending_up,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ReportCard(
                          title: loc('total_purchases'),
                          amount: _summary['purchaseCost'] ?? 0,
                          color: const Color(0xFF2563EB),
                          icon: Icons.shopping_bag,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _ReportCard(
                          title: loc('total_wastage'),
                          amount: _summary['wastageLoss'] ?? 0,
                          color: const Color(0xFFDC2626),
                          icon: Icons.delete_outline,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ReportCard(
                          title: loc('net_profit'),
                          amount: _summary['netProfit'] ?? 0,
                          color: (_summary['netProfit'] ?? 0) >= 0 
                              ? const Color(0xFF138808) 
                              : const Color(0xFFDC2626),
                          icon: (_summary['netProfit'] ?? 0) >= 0 
                              ? Icons.arrow_upward 
                              : Icons.arrow_downward,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  Text(
                    loc('top_selling'),
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _topProducts.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(32),
                            child: Text(
                              'No sales data yet',
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                          ),
                        )
                      : Column(
                          children: _topProducts.asMap().entries.map((entry) {
                            final index = entry.key;
                            final product = entry.value;
                            final isTop = index == 0;

                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              color: isTop ? const Color(0xFFFFF8F0) : null,
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: isTop 
                                      ? Colors.amber.withOpacity(0.2)
                                      : Colors.grey.shade200,
                                  child: Text(
                                    '${index + 1}',
                                    style: TextStyle(
                                      color: isTop ? Colors.amber.shade800 : Colors.grey.shade700,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                title: Text(
                                  LocalizationService.currentLocale.languageCode == 'ne'
                                      ? product['name_np']
                                      : product['name_en'],
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                                subtitle: Text(
                                  '${LocalizationService.formatNumber(product['total_qty'])} KG sold',
                                ),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      LocalizationService.formatCurrency(product['total_amount']),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    if (isTop)
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.amber.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: const Text(
                                          'TOP',
                                          style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.amber,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),

                  const SizedBox(height: 24),

                  const Text(
                    'Payment Breakdown',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildPaymentBreakdown(),
                ],
              ),
            ),
    );
  }

  Widget _buildPaymentBreakdown() {
    final methods = ['cash', 'qr', 'credit'];
    final colors = {
      'cash': const Color(0xFF138808),
      'qr': const Color(0xFF2563EB),
      'credit': Colors.orange,
    };
    final icons = {
      'cash': Icons.money,
      'qr': Icons.qr_code,
      'credit': Icons.credit_card,
    };

    return FutureBuilder<Map<String, double>>(
      future: DatabaseService.instance.getSalesByPaymentMethod(
        DateTime.now().toIso8601String().split('T')[0],
      ),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();

        final data = snapshot.data!;
        final total = data.values.fold<double>(0, (sum, v) => sum + v);

        return Column(
          children: methods.map((method) {
            final amount = data[method] ?? 0;
            final percentage = total > 0 ? (amount / total * 100) : 0;

            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(icons[method], color: colors[method], size: 20),
                      const SizedBox(width: 8),
                      Text(
                        method.toUpperCase(),
                        style: TextStyle(
                          color: colors[method],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        LocalizationService.formatCurrency(amount),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: percentage / 100,
                      minHeight: 8,
                      backgroundColor: Colors.grey.shade200,
                      valueColor: AlwaysStoppedAnimation<Color>(colors[method]!),
                    ),
                  ),
                  Text(
                    '${percentage.toStringAsFixed(1)}%',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _ReportCard extends StatelessWidget {
  final String title;
  final double amount;
  final Color color;
  final IconData icon;

  const _ReportCard({
    required this.title,
    required this.amount,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            LocalizationService.formatCurrency(amount),
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
