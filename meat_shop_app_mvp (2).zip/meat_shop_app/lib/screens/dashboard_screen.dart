import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';
import '../widgets/summary_card.dart';
import '../widgets/stock_grid.dart';
import 'sales_screen.dart';
import 'expense_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic> _summary = {};
  List<Map<String, dynamic>> _products = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final today = DateTime.now().toIso8601String().split('T')[0];
    final summary = await DatabaseService.instance.getDashboardSummary(today);
    final products = await DatabaseService.instance.getProducts();

    if (mounted) {
      setState(() {
        _summary = summary;
        _products = products;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('app_title')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () {
              LocalizationService.toggleLanguage();
              setState(() {});
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Date Header
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFC41E3A).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${loc('todays_summary')} - ${DateTime.now().toString().split(' ')[0]}',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFC41E3A),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Financial Summary Cards
                    Row(
                      children: [
                        Expanded(
                          child: SummaryCard(
                            title: loc('today_income'),
                            amount: _summary['income'] ?? 0.0,
                            color: const Color(0xFF138808),
                            icon: Icons.trending_up,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: SummaryCard(
                            title: loc('today_expense'),
                            amount: _summary['expenses'] ?? 0.0,
                            color: const Color(0xFFDC2626),
                            icon: Icons.trending_down,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Net Profit Card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: (_summary['netProfit'] ?? 0) >= 0
                              ? [const Color(0xFF138808), const Color(0xFF0D5C0A)]
                              : [const Color(0xFFDC2626), const Color(0xFFB91C1C)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: ((_summary['netProfit'] ?? 0) >= 0 ? const Color(0xFF138808) : const Color(0xFFDC2626)).withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Text(
                            loc('net_profit'),
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            LocalizationService.formatCurrency(_summary['netProfit'] ?? 0.0),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Icon(
                            (_summary['netProfit'] ?? 0) >= 0 ? Icons.arrow_upward : Icons.arrow_downward,
                            color: Colors.white70,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Live Stock Section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          loc('live_stock'),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1F2937),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFC41E3A).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF138808),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                loc('synced'),
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF138808),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    StockGrid(products: _products),
                    const SizedBox(height: 24),

                    // Quick Actions
                    Text(
                      loc('quick_actions'),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1F2937),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _QuickActionButton(
                            icon: Icons.add_shopping_cart,
                            label: loc('record_sale'),
                            color: const Color(0xFFC41E3A),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const SalesScreen()),
                            ).then((_) => _loadData()),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _QuickActionButton(
                            icon: Icons.shopping_bag,
                            label: loc('add_purchase'),
                            color: const Color(0xFF2563EB),
                            onTap: () => _showPurchaseDialog(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _QuickActionButton(
                            icon: Icons.delete_outline,
                            label: loc('log_wastage'),
                            color: const Color(0xFFDC2626),
                            onTap: () => _showWastageDialog(),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _QuickActionButton(
                            icon: Icons.receipt_long,
                            label: loc('add_expense'),
                            color: const Color(0xFF7C3AED),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const ExpenseScreen()),
                            ).then((_) => _loadData()),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const SalesScreen()),
        ).then((_) => _loadData()),
        backgroundColor: const Color(0xFFC41E3A),
        icon: const Icon(Icons.add),
        label: Text(loc('new_sale')),
      ),
    );
  }

  void _showPurchaseDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const PurchaseBottomSheet(),
    ).then((_) => _loadData());
  }

  void _showWastageDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const WastageBottomSheet(),
    ).then((_) => _loadData());
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class PurchaseBottomSheet extends StatefulWidget {
  const PurchaseBottomSheet({super.key});

  @override
  State<PurchaseBottomSheet> createState() => _PurchaseBottomSheetState();
}

class _PurchaseBottomSheetState extends State<PurchaseBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  int? _selectedProductId;
  String _purchaseType = 'ready_meat';
  final _quantityController = TextEditingController();
  final _rateController = TextEditingController();
  final _supplierController = TextEditingController();
  List<Map<String, dynamic>> _products = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final products = await DatabaseService.instance.getProducts();
    setState(() => _products = products);
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              loc('add_purchase'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _selectedProductId,
              hint: Text(loc('meat_type')),
              items: _products.map((p) => DropdownMenuItem(
                value: p['id'] as int,
                child: Text(LocalizationService.currentLocale.languageCode == 'ne' 
                    ? p['name_np'] 
                    : p['name_en']),
              )).toList(),
              onChanged: (v) => setState(() => _selectedProductId = v),
              validator: (v) => v == null ? loc('required_field') : null,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ChoiceChip(
                    label: Text(loc('live_animal')),
                    selected: _purchaseType == 'live_animal',
                    onSelected: (selected) => setState(() => _purchaseType = 'live_animal'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ChoiceChip(
                    label: Text(loc('ready_meat')),
                    selected: _purchaseType == 'ready_meat',
                    onSelected: (selected) => setState(() => _purchaseType = 'ready_meat'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _quantityController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: loc('quantity_kg')),
              validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _rateController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: loc('rate_per_kg')),
              validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _supplierController,
              decoration: InputDecoration(labelText: loc('supplier')),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _savePurchase,
                child: Text(loc('save')),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _savePurchase() async {
    if (!_formKey.currentState!.validate()) return;

    final qty = double.parse(_quantityController.text);
    final rate = double.parse(_rateController.text);

    await DatabaseService.instance.addPurchase({
      'product_id': _selectedProductId,
      'purchase_type': _purchaseType,
      'quantity_kg': qty,
      'rate_per_kg': rate,
      'total_cost': qty * rate,
      'supplier_name': _supplierController.text.isEmpty ? null : _supplierController.text,
      'purchase_date': DateTime.now().toIso8601String().split('T')[0],
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(LocalizationService.translate('purchase_saved'))),
      );
      Navigator.pop(context);
    }
  }
}

class WastageBottomSheet extends StatefulWidget {
  const WastageBottomSheet({super.key});

  @override
  State<WastageBottomSheet> createState() => _WastageBottomSheetState();
}

class _WastageBottomSheetState extends State<WastageBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  int? _selectedProductId;
  String _wastageType = 'spoilage';
  final _quantityController = TextEditingController();
  final _reasonController = TextEditingController();
  List<Map<String, dynamic>> _products = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final products = await DatabaseService.instance.getProducts();
    setState(() => _products = products);
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              loc('log_wastage'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _selectedProductId,
              hint: Text(loc('meat_type')),
              items: _products.map((p) => DropdownMenuItem(
                value: p['id'] as int,
                child: Text(LocalizationService.currentLocale.languageCode == 'ne' 
                    ? p['name_np'] 
                    : p['name_en']),
              )).toList(),
              onChanged: (v) => setState(() => _selectedProductId = v),
              validator: (v) => v == null ? loc('required_field') : null,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: Text(loc('bone_waste')),
                  selected: _wastageType == 'bone_waste',
                  onSelected: (s) => setState(() => _wastageType = 'bone_waste'),
                ),
                ChoiceChip(
                  label: Text(loc('spoilage')),
                  selected: _wastageType == 'spoilage',
                  onSelected: (s) => setState(() => _wastageType = 'spoilage'),
                ),
                ChoiceChip(
                  label: Text(loc('cutting_loss')),
                  selected: _wastageType == 'cutting_loss',
                  onSelected: (s) => setState(() => _wastageType = 'cutting_loss'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _quantityController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: loc('quantity_kg')),
              validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _reasonController,
              decoration: InputDecoration(labelText: loc('reason')),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveWastage,
                child: Text(loc('save')),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _saveWastage() async {
    if (!_formKey.currentState!.validate()) return;

    final product = await DatabaseService.instance.getProduct(_selectedProductId!);
    if (product == null) return;

    final qty = double.parse(_quantityController.text);
    final currentStock = product['current_stock_kg'] as double;

    if (qty > currentStock) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(LocalizationService.translate('insufficient_stock'))),
      );
      return;
    }

    final rate = product['avg_buying_rate'] as double? ?? 0;
    final loss = qty * (rate > 0 ? rate : 500); // Default rate if not set

    await DatabaseService.instance.addWastage({
      'product_id': _selectedProductId,
      'wastage_type': _wastageType,
      'quantity_kg': qty,
      'financial_loss': loss,
      'reason': _reasonController.text.isEmpty ? null : _reasonController.text,
      'date': DateTime.now().toIso8601String().split('T')[0],
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(LocalizationService.translate('wastage_logged'))),
      );
      Navigator.pop(context);
    }
  }
}
