import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';

class ExpenseScreen extends StatefulWidget {
  const ExpenseScreen({super.key});

  @override
  State<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  final _formKey = GlobalKey<FormState>();
  String _category = 'rent';
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  List<Map<String, dynamic>> _todayExpenses = [];

  final List<String> _categories = [
    'rent', 'electricity', 'salary', 'transportation', 'feed_supplies', 'miscellaneous'
  ];

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    final today = DateTime.now().toIso8601String().split('T')[0];
    final expenses = await DatabaseService.instance.getExpenses(date: today);
    if (mounted) {
      setState(() => _todayExpenses = expenses);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('expenses')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        loc('add_expense'),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFC41E3A),
                        ),
                      ),
                      const SizedBox(height: 16),

                      DropdownButtonFormField<String>(
                        value: _category,
                        decoration: InputDecoration(
                          labelText: loc('expense_category'),
                          prefixIcon: const Icon(Icons.category),
                        ),
                        items: _categories.map((cat) => DropdownMenuItem(
                          value: cat,
                          child: Text(loc(cat)),
                        )).toList(),
                        onChanged: (v) => setState(() => _category = v!),
                      ),
                      const SizedBox(height: 12),

                      TextFormField(
                        controller: _amountController,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: InputDecoration(
                          labelText: loc('amount'),
                          prefixIcon: const Icon(Icons.attach_money),
                        ),
                        validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
                      ),
                      const SizedBox(height: 12),

                      TextFormField(
                        controller: _descriptionController,
                        decoration: InputDecoration(
                          labelText: loc('description'),
                          prefixIcon: const Icon(Icons.notes),
                        ),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 20),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _saveExpense,
                          icon: const Icon(Icons.save),
                          label: Text(loc('save')),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            Text(
              '${loc('todays_summary')} - ${loc('expenses')}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            _todayExpenses.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        'No expenses today',
                        style: TextStyle(color: Colors.grey.shade500),
                      ),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _todayExpenses.length,
                    itemBuilder: (context, index) {
                      final expense = _todayExpenses[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFDC2626).withOpacity(0.2),
                            child: const Icon(Icons.receipt, color: Color(0xFFDC2626), size: 20),
                          ),
                          title: Text(loc(expense['category'])),
                          subtitle: expense['description'] != null
                              ? Text(expense['description'], maxLines: 1, overflow: TextOverflow.ellipsis)
                              : null,
                          trailing: Text(
                            LocalizationService.formatCurrency(expense['amount']),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFDC2626),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  void _saveExpense() async {
    if (!_formKey.currentState!.validate()) return;

    await DatabaseService.instance.addExpense({
      'category': _category,
      'amount': double.parse(_amountController.text),
      'description': _descriptionController.text.isEmpty ? null : _descriptionController.text,
      'expense_date': DateTime.now().toIso8601String().split('T')[0],
    });

    _amountController.clear();
    _descriptionController.clear();
    await _loadExpenses();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(LocalizationService.translate('expense_saved')),
          backgroundColor: const Color(0xFF138808),
        ),
      );
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}
