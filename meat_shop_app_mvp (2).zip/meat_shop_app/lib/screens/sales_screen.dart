import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';

class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  final _formKey = GlobalKey<FormState>();
  int? _selectedProductId;
  String _paymentMethod = 'cash';
  int? _selectedCustomerId;
  final _quantityController = TextEditingController();
  final _rateController = TextEditingController();
  final _customerNameController = TextEditingController();
  final _customerPhoneController = TextEditingController();
  final _notesController = TextEditingController();

  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _customers = [];
  List<Map<String, dynamic>> _todaySales = [];
  double _totalAmount = 0.0;
  bool _isNewCustomer = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _quantityController.addListener(_calculateTotal);
    _rateController.addListener(_calculateTotal);
  }

  Future<void> _loadData() async {
    final products = await DatabaseService.instance.getProducts();
    final customers = await DatabaseService.instance.getCustomers();
    final today = DateTime.now().toIso8601String().split('T')[0];
    final sales = await DatabaseService.instance.getSales(date: today);

    if (mounted) {
      setState(() {
        _products = products;
        _customers = customers;
        _todaySales = sales;
      });
    }
  }

  void _calculateTotal() {
    final qty = double.tryParse(_quantityController.text) ?? 0;
    final rate = double.tryParse(_rateController.text) ?? 0;
    setState(() => _totalAmount = qty * rate);
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('sales')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // New Sale Form
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        loc('new_sale'),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFC41E3A),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Product Selection
                      DropdownButtonFormField<int>(
                        value: _selectedProductId,
                        hint: Text(loc('meat_type')),
                        decoration: InputDecoration(
                          labelText: loc('meat_type'),
                          prefixIcon: const Icon(Icons.restaurant_menu),
                        ),
                        items: _products.map((p) {
                          final name = LocalizationService.currentLocale.languageCode == 'ne' 
                              ? p['name_np'] 
                              : p['name_en'];
                          final stock = p['current_stock_kg'];
                          return DropdownMenuItem(
                            value: p['id'] as int,
                            child: Text('$name (${LocalizationService.formatNumber(stock)} ${loc('kg')})'),
                          );
                        }).toList(),
                        onChanged: (v) => setState(() => _selectedProductId = v),
                        validator: (v) => v == null ? loc('required_field') : null,
                      ),
                      const SizedBox(height: 12),

                      // Quantity and Rate
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _quantityController,
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              decoration: InputDecoration(
                                labelText: loc('quantity_kg'),
                                prefixIcon: const Icon(Icons.scale),
                              ),
                              validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextFormField(
                              controller: _rateController,
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              decoration: InputDecoration(
                                labelText: loc('rate_per_kg'),
                                prefixIcon: const Icon(Icons.attach_money),
                              ),
                              validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Total Amount Display
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFC41E3A).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: [
                            Text(
                              loc('total_amount'),
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              LocalizationService.formatCurrency(_totalAmount),
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFC41E3A),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Payment Method
                      Text(
                        loc('payment_method'),
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          _PaymentMethodChip(
                            icon: Icons.money,
                            label: loc('cash'),
                            isSelected: _paymentMethod == 'cash',
                            onTap: () => setState(() => _paymentMethod = 'cash'),
                          ),
                          const SizedBox(width: 8),
                          _PaymentMethodChip(
                            icon: Icons.qr_code,
                            label: loc('qr_code'),
                            isSelected: _paymentMethod == 'qr',
                            onTap: () => setState(() => _paymentMethod = 'qr'),
                          ),
                          const SizedBox(width: 8),
                          _PaymentMethodChip(
                            icon: Icons.credit_card,
                            label: loc('credit'),
                            isSelected: _paymentMethod == 'credit',
                            onTap: () => setState(() => _paymentMethod = 'credit'),
                            color: Colors.orange,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Credit Customer Section
                      if (_paymentMethod == 'credit') ...[
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.orange.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.orange.withOpacity(0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.person_add, color: Colors.orange, size: 20),
                                  const SizedBox(width: 8),
                                  Text(
                                    loc('udharo'),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.orange,
                                    ),
                                  ),
                                  const Spacer(),
                                  TextButton.icon(
                                    onPressed: () => setState(() => _isNewCustomer = !_isNewCustomer),
                                    icon: Icon(_isNewCustomer ? Icons.people : Icons.person_add),
                                    label: Text(_isNewCustomer ? 'Existing' : 'New'),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              if (_isNewCustomer) ...[
                                TextFormField(
                                  controller: _customerNameController,
                                  decoration: InputDecoration(
                                    labelText: loc('customer_name'),
                                    prefixIcon: const Icon(Icons.person),
                                  ),
                                  validator: (v) => v?.isEmpty ?? true ? loc('required_field') : null,
                                ),
                                const SizedBox(height: 8),
                                TextFormField(
                                  controller: _customerPhoneController,
                                  keyboardType: TextInputType.phone,
                                  decoration: InputDecoration(
                                    labelText: loc('customer_phone'),
                                    prefixIcon: const Icon(Icons.phone),
                                  ),
                                  validator: (v) {
                                    if (v?.isEmpty ?? true) return loc('required_field');
                                    if (v!.length < 10) return loc('invalid_phone');
                                    return null;
                                  },
                                ),
                              ] else ...[
                                DropdownButtonFormField<int>(
                                  value: _selectedCustomerId,
                                  hint: Text(loc('search_customer')),
                                  items: _customers.map((c) => DropdownMenuItem(
                                    value: c['id'] as int,
                                    child: Text('${c['name']} (Rs. ${c['total_credit'] - c['total_paid']})'),
                                  )).toList(),
                                  onChanged: (v) => setState(() => _selectedCustomerId = v),
                                  validator: (v) => v == null ? loc('required_field') : null,
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],

                      // Notes
                      TextFormField(
                        controller: _notesController,
                        decoration: InputDecoration(
                          labelText: loc('description'),
                          prefixIcon: const Icon(Icons.notes),
                        ),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 20),

                      // Save Button
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: _saveSale,
                          icon: const Icon(Icons.save),
                          label: Text(
                            loc('save_sale'),
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Today's Sales List
            Text(
              '${loc('todays_summary')} - ${loc('sales')}',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            _todaySales.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        children: [
                          Icon(Icons.receipt_long_outlined, size: 48, color: Colors.grey.shade400),
                          const SizedBox(height: 8),
                          Text(
                            'No sales today',
                            style: TextStyle(color: Colors.grey.shade500),
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _todaySales.length,
                    itemBuilder: (context, index) {
                      final sale = _todaySales[index];
                      return _SaleListTile(sale: sale);
                    },
                  ),
          ],
        ),
      ),
    );
  }

  void _saveSale() async {
    if (!_formKey.currentState!.validate()) return;

    final product = await DatabaseService.instance.getProduct(_selectedProductId!);
    if (product == null) return;

    final qty = double.parse(_quantityController.text);
    final currentStock = product['current_stock_kg'] as double;

    if (qty > currentStock) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(LocalizationService.translate('insufficient_stock'))),
      );
      return;
    }

    int? customerId = _selectedCustomerId;

    // Create new customer if needed
    if (_paymentMethod == 'credit' && _isNewCustomer) {
      customerId = await DatabaseService.instance.addCustomer({
        'name': _customerNameController.text,
        'phone': _customerPhoneController.text,
      });
      // Refresh customers list
      final customers = await DatabaseService.instance.getCustomers();
      setState(() => _customers = customers);
    }

    await DatabaseService.instance.addSale({
      'product_id': _selectedProductId,
      'quantity_kg': qty,
      'rate_per_kg': double.parse(_rateController.text),
      'total_amount': _totalAmount,
      'payment_method': _paymentMethod,
      'customer_id': customerId,
      'customer_name': _customerNameController.text.isNotEmpty ? _customerNameController.text : null,
      'customer_phone': _customerPhoneController.text.isNotEmpty ? _customerPhoneController.text : null,
      'sale_date': DateTime.now().toIso8601String().split('T')[0],
      'notes': _notesController.text.isEmpty ? null : _notesController.text,
    });

    // Reset form
    _quantityController.clear();
    _rateController.clear();
    _customerNameController.clear();
    _customerPhoneController.clear();
    _notesController.clear();
    setState(() {
      _selectedProductId = null;
      _selectedCustomerId = null;
      _totalAmount = 0;
      _isNewCustomer = false;
    });

    await _loadData();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(LocalizationService.translate('sale_saved')),
          backgroundColor: const Color(0xFF138808),
        ),
      );
    }
  }

  @override
  void dispose() {
    _quantityController.dispose();
    _rateController.dispose();
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}

class _PaymentMethodChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color? color;

  const _PaymentMethodChip({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final selectedColor = color ?? const Color(0xFFC41E3A);
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? selectedColor : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isSelected ? selectedColor : Colors.grey.shade300,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? Colors.white : selectedColor, size: 24),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : selectedColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SaleListTile extends StatelessWidget {
  final Map<String, dynamic> sale;

  const _SaleListTile({required this.sale});

  @override
  Widget build(BuildContext context) {
    final paymentIcons = {
      'cash': Icons.money,
      'qr': Icons.qr_code,
      'credit': Icons.credit_card,
    };
    final paymentColors = {
      'cash': const Color(0xFF138808),
      'qr': const Color(0xFF2563EB),
      'credit': Colors.orange,
    };

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: paymentColors[sale['payment_method']]?.withOpacity(0.2),
          child: Icon(
            paymentIcons[sale['payment_method']] ?? Icons.payment,
            color: paymentColors[sale['payment_method']],
            size: 20,
          ),
        ),
        title: Text(
          '${LocalizationService.formatNumber(sale['quantity_kg'])} KG @ ${LocalizationService.formatCurrency(sale['rate_per_kg'])}',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          'Total: ${LocalizationService.formatCurrency(sale['total_amount'])}',
        ),
        trailing: Text(
          LocalizationService.formatCurrency(sale['total_amount']),
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: Color(0xFF1F2937),
          ),
        ),
      ),
    );
  }
}
