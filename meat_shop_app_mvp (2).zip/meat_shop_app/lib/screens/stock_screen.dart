import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/localization_service.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  List<Map<String, dynamic>> _products = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final products = await DatabaseService.instance.getProducts();
    if (mounted) {
      setState(() {
        _products = products;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = LocalizationService.translate;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc('stock')),
        backgroundColor: const Color(0xFFC41E3A),
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadProducts,
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _products.length,
                itemBuilder: (context, index) {
                  final product = _products[index];
                  final stock = product['current_stock_kg'] as double;
                  final minStock = product['min_stock_alert_kg'] as double;
                  final isLow = stock <= minStock;
                  final isCritical = stock <= 0;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: isCritical 
                                      ? const Color(0xFFDC2626).withOpacity(0.2)
                                      : isLow 
                                          ? Colors.orange.withOpacity(0.2)
                                          : const Color(0xFF138808).withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  Icons.restaurant,
                                  color: isCritical 
                                      ? const Color(0xFFDC2626)
                                      : isLow 
                                          ? Colors.orange
                                          : const Color(0xFF138808),
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      LocalizationService.currentLocale.languageCode == 'ne'
                                          ? product['name_np']
                                          : product['name_en'],
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${loc('avg_buying_rate')}: ${LocalizationService.formatCurrency(product['avg_buying_rate'] ?? 0)}',
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isCritical 
                                      ? const Color(0xFFDC2626).withOpacity(0.1)
                                      : isLow 
                                          ? Colors.orange.withOpacity(0.1)
                                          : const Color(0xFF138808).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  isCritical ? 'OUT OF STOCK' : isLow ? loc('low_stock_alert') : 'In Stock',
                                  style: TextStyle(
                                    color: isCritical 
                                        ? const Color(0xFFDC2626)
                                        : isLow 
                                            ? Colors.orange
                                            : const Color(0xFF138808),
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          // Stock Bar
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: stock > 50 ? 1.0 : stock / 50,
                              minHeight: 12,
                              backgroundColor: Colors.grey.shade200,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                isCritical 
                                    ? const Color(0xFFDC2626)
                                    : isLow 
                                        ? Colors.orange
                                        : const Color(0xFF138808),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${LocalizationService.formatNumber(stock)} ${loc('kg')}',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: isCritical 
                                      ? const Color(0xFFDC2626)
                                      : isLow 
                                          ? Colors.orange
                                          : const Color(0xFF1F2937),
                                ),
                              ),
                              Text(
                                'Min: ${LocalizationService.formatNumber(minStock)} ${loc('kg')}',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),

                          // Quick Actions
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () => _showAdjustStockDialog(product),
                                  icon: const Icon(Icons.edit, size: 18),
                                  label: const Text('Adjust'),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: const Color(0xFFC41E3A),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () => _showSetAlertDialog(product),
                                  icon: const Icon(Icons.notifications, size: 18),
                                  label: const Text('Alert'),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.orange,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  void _showAdjustStockDialog(Map<String, dynamic> product) {
    final controller = TextEditingController(text: product['current_stock_kg'].toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Adjust Stock - ${product['name_en']}'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'New Stock (KG)',
            prefixIcon: Icon(Icons.scale),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(LocalizationService.translate('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              final newStock = double.tryParse(controller.text) ?? 0;
              await DatabaseService.instance.updateProductStock(product['id'], newStock);
              Navigator.pop(context);
              _loadProducts();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Stock updated')),
              );
            },
            child: Text(LocalizationService.translate('save')),
          ),
        ],
      ),
    );
  }

  void _showSetAlertDialog(Map<String, dynamic> product) {
    // Implementation for setting alert threshold
    final controller = TextEditingController(text: (product['min_stock_alert_kg'] ?? 3).toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set Alert - ${product['name_en']}'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Minimum Stock Alert (KG)',
            prefixIcon: Icon(Icons.notifications),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(LocalizationService.translate('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              final alertLevel = double.tryParse(controller.text) ?? 3;
              // Would need to add updateMinStockAlert method to DB service
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Alert threshold updated')),
              );
            },
            child: Text(LocalizationService.translate('save')),
          ),
        ],
      ),
    );
  }
}
