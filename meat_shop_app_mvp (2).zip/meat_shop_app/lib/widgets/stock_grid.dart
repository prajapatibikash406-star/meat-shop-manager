import 'package:flutter/material.dart';
import '../services/localization_service.dart';

class StockGrid extends StatelessWidget {
  final List<Map<String, dynamic>> products;

  const StockGrid({super.key, required this.products});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.4,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: products.length,
      itemBuilder: (context, index) {
        final product = products[index];
        final stock = product['current_stock_kg'] as double;
        final minStock = product['min_stock_alert_kg'] as double;
        final isLow = stock <= minStock;
        final isCritical = stock <= 0;

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isCritical
                  ? const Color(0xFFDC2626).withOpacity(0.3)
                  : isLow
                      ? Colors.orange.withOpacity(0.3)
                      : const Color(0xFF138808).withOpacity(0.2),
              width: 2,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: isCritical
                      ? const Color(0xFFDC2626).withOpacity(0.1)
                      : isLow
                          ? Colors.orange.withOpacity(0.1)
                          : const Color(0xFF138808).withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.restaurant,
                  color: isCritical
                      ? const Color(0xFFDC2626)
                      : isLow
                          ? Colors.orange
                          : const Color(0xFF138808),
                  size: 20,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                LocalizationService.currentLocale.languageCode == 'ne'
                    ? product['name_np']
                    : product['name_en'],
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${LocalizationService.formatNumber(stock)} ${LocalizationService.translate('kg')}',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: isCritical
                      ? const Color(0xFFDC2626)
                      : isLow
                          ? Colors.orange
                          : const Color(0xFF138808),
                ),
              ),
              if (isLow || isCritical)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: isCritical
                        ? const Color(0xFFDC2626).withOpacity(0.1)
                        : Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    isCritical ? 'EMPTY' : 'LOW',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: isCritical ? const Color(0xFFDC2626) : Colors.orange,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
