
# 🥩 Meat Shop Manager - Complete Testing & Deployment Guide
# मासु पसल प्रबन्धक - पूर्ण परीक्षण र डिप्लोयमेन्ट गाइड

================================================================================
PART 1: DEVELOPMENT SETUP (विकास वातावरण सेटअप)
================================================================================

## 1.1 System Requirements (सिस्टम आवश्यकताहरू)

### Minimum Requirements:
- RAM: 8 GB
- Storage: 10 GB free space
- OS: Windows 10/11, macOS 10.14+, or Ubuntu 20.04+
- Internet: Required for initial setup

### Software Needed:
1. Flutter SDK (latest stable)
2. Android Studio or VS Code
3. Android SDK
4. Git

## 1.2 Flutter Installation (Windows)

```powershell
# Step 1: Download Flutter
# https://docs.flutter.dev/get-started/install/windows

# Step 2: Extract to C:lutter
# Add to PATH: C:lutterin

# Step 3: Verify
flutter doctor

# Expected output:
[✓] Flutter (Channel stable, 3.x.x)
[✓] Android toolchain
[✓] Android Studio
[✓] Connected device
```

## 1.3 Project Setup

```bash
# Navigate to project folder
cd meat_shop_app

# Get dependencies
flutter pub get

# Verify build
flutter build apk --debug
```

================================================================================
PART 2: TESTING (परीक्षण)
================================================================================

## 2.1 Unit Test Cases

### Test Suite 1: Database Operations
```dart
// test/database_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  group('Database Tests', () {
    test('Product stock updates after sale', () async {
      // Arrange
      final db = await openDatabase(':memory:');
      await db.execute('CREATE TABLE products (id INTEGER PRIMARY KEY, current_stock_kg REAL)');
      await db.insert('products', {'id': 1, 'current_stock_kg': 25.0});

      // Act
      await db.rawUpdate('UPDATE products SET current_stock_kg = current_stock_kg - ? WHERE id = ?', [2.5, 1]);

      // Assert
      final result = await db.query('products', where: 'id = ?', whereArgs: [1]);
      expect(result.first['current_stock_kg'], 22.5);
    });

    test('Customer credit increases on sale', () async {
      // Arrange
      final db = await openDatabase(':memory:');
      await db.execute('CREATE TABLE customers (id INTEGER PRIMARY KEY, total_credit REAL, total_paid REAL)');
      await db.insert('customers', {'id': 1, 'total_credit': 0, 'total_paid': 0});

      // Act
      await db.rawUpdate('UPDATE customers SET total_credit = total_credit + ? WHERE id = ?', [1000.0, 1]);

      // Assert
      final result = await db.query('customers', where: 'id = ?', whereArgs: [1]);
      expect(result.first['total_credit'], 1000.0);
    });
  });
}
```

### Test Suite 2: Localization
```dart
// test/localization_test.dart
void main() {
  group('Localization Tests', () {
    test('English translation works', () {
      expect(LocalizationService.translate('dashboard'), 'Dashboard');
    });

    test('Nepali translation works', () {
      LocalizationService.localeNotifier.value = const Locale('ne', 'NP');
      expect(LocalizationService.translate('dashboard'), 'ड्यासबोर्ड');
    });

    test('Currency formatting in Nepali', () {
      LocalizationService.localeNotifier.value = const Locale('ne', 'NP');
      expect(LocalizationService.formatCurrency(1000), 'रु 1000');
    });
  });
}
```

## 2.2 Integration Tests

```dart
// integration_test/app_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:meat_shop_app/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('End-to-End Tests', () {
    test('Complete sale flow', () async {
      app.main();
      await tester.pumpAndSettle();

      // Navigate to Sales
      await tester.tap(find.text('Sales'));
      await tester.pumpAndSettle();

      // Select product
      await tester.tap(find.byType(DropdownButtonFormField<int>));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Chicken (25.0 KG)'));
      await tester.pumpAndSettle();

      // Enter quantity
      await tester.enterText(find.byType(TextFormField).first, '2.5');

      // Enter rate
      await tester.enterText(find.byType(TextFormField).at(1), '450');

      // Select cash payment
      await tester.tap(find.text('Cash'));
      await tester.pumpAndSettle();

      // Save sale
      await tester.tap(find.text('Save Sale'));
      await tester.pumpAndSettle();

      // Verify success message
      expect(find.text('Sale saved successfully'), findsOneWidget);
    });

    test('Language toggle', () async {
      app.main();
      await tester.pumpAndSettle();

      // Tap language icon
      await tester.tap(find.byIcon(Icons.language));
      await tester.pumpAndSettle();

      // Verify Nepali text
      expect(find.text('ड्यासबोर्ड'), findsOneWidget);
    });
  });
}
```

## 2.3 Manual Testing Checklist

### Dashboard Screen
- [ ] Income card shows correct amount
- [ ] Expense card shows correct amount
- [ ] Net profit calculates correctly
- [ ] Stock grid displays all products
- [ ] Low stock alerts appear correctly
- [ ] Language toggle works
- [ ] Pull-to-refresh updates data
- [ ] Quick action buttons navigate correctly

### Sales Screen
- [ ] Product dropdown shows stock levels
- [ ] Total amount auto-calculates
- [ ] All payment methods selectable
- [ ] Credit shows customer fields
- [ ] New customer can be added
- [ ] Existing customer selectable
- [ ] Sale saves successfully
- [ ] Stock deducts after sale
- [ ] Today's sales list updates

### Udharo Screen
- [ ] Customer list displays
- [ ] Outstanding amount calculates
- [ ] Payment recording works
- [ ] Payment history shows
- [ ] New customer can be added
- [ ] Customer detail bottom sheet opens

### Stock Screen
- [ ] All products display
- [ ] Stock levels accurate
- [ ] Color coding works (green/orange/red)
- [ ] Low stock alerts visible
- [ ] Stock adjustment works
- [ ] Alert threshold setting works

### Expense Screen
- [ ] All categories available
- [ ] Amount validation works
- [ ] Expense saves successfully
- [ ] Today's expenses list updates

### Reports Screen
- [ ] Period selector works
- [ ] Summary cards update
- [ ] Top selling products display
- [ ] Payment breakdown shows

================================================================================
PART 3: BUILD & DEPLOY (बिल्ड र डिप्लोय)
================================================================================

## 3.1 Debug Build (Testing को लागि)

```bash
# Android APK (Debug)
flutter build apk --debug

# Output: build/app/outputs/flutter-apk/app-debug.apk
# Size: ~20-30 MB
```

## 3.2 Release Build (Distribution को लागि)

```bash
# Android APK (Release)
flutter build apk --release

# Output: build/app/outputs/flutter-apk/app-release.apk
# Size: ~15-20 MB

# Android App Bundle (Play Store को लागि)
flutter build appbundle --release

# Output: build/app/outputs/bundle/release/app-release.aab
# Size: ~12-18 MB
```

## 3.3 Signing (Production को लागि)

```bash
# Step 1: Generate keystore
keytool -genkey -v   -keystore ~/upload-keystore.jks   -keyalg RSA   -keysize 2048   -validity 10000   -alias upload

# Step 2: Create key.properties
cat > android/key.properties << EOF
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=upload
storeFile=../upload-keystore.jks
EOF

# Step 3: Update build.gradle
cat >> android/app/build.gradle << 'EOF'

def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
EOF

# Step 4: Build signed APK
flutter build apk --release
```

## 3.4 Play Store Upload

```bash
# 1. Create Google Play Developer Account
# https://play.google.com/console
# Fee: $25 one-time

# 2. Create New App
# - App name: "Meat Shop Manager"
# - Default language: English
# - App or game: App
# - Free or paid: Free

# 3. Upload AAB file
# Build > App bundles > Upload

# 4. Fill Store Listing
# - Screenshots (phone + tablet)
# - Feature graphic
# - App description (EN + NE)
# - Privacy policy

# 5. Content Rating
# - Category: Shopping / Business
# - Questionnaire fill गर्नुहोस्

# 6. Pricing & Distribution
# - Countries: Nepal, India, etc.
# - Price: Free

# 7. Submit for Review
# - Review time: 1-7 days
```

================================================================================
PART 4: INSTALLATION GUIDE (इन्स्टलेशन गाइड)
================================================================================

## 4.1 Direct APK Install (User को लागि)

### Android Phone मा:

```
Step 1: APK File Download गर्नुहोस्
┌─────────────────────────────────────┐
│  📥 Download app-release.apk        │
│  Size: ~18 MB                       │
└─────────────────────────────────────┘

Step 2: Settings खोल्नुहोस्
┌─────────────────────────────────────┐
│  ⚙️ Settings > Security             │
│  🔓 Unknown Sources: ON गर्नुहोस्   │
│  (वा: Settings > Apps > Special     │
│   Access > Install Unknown Apps)    │
└─────────────────────────────────────┘

Step 3: Install गर्नुहोस्
┌─────────────────────────────────────┐
│  📂 File Manager मा जानुहोस्       │
│  📄 app-release.apk tap गर्नुहोस्   │
│  ✅ Install थिच्नुहोस्              │
└─────────────────────────────────────┘

Step 4: App खोल्नुहोस्
┌─────────────────────────────────────┐
│  🥩 Meat Shop Manager icon tap      │
│  🎉 Ready to use!                   │
└─────────────────────────────────────┘
```

### Troubleshooting:
```
❌ "App not installed" error
   ✅ Solution: पुरानो version uninstall गरेर फेरि try गर्नुहोस्

❌ "Blocked by Play Protect" 
   ✅ Solution: "Install anyway" थिच्नुहोस्

❌ "Parse error"
   ✅ Solution: Android version 5.0+ चाहिन्छ
```

## 4.2 Play Store Install

```
Step 1: Google Play Store खोल्नुहोस्
Step 2: "Meat Shop Manager" search गर्नुहोस्
Step 3: Install button थिच्नुहोस्
Step 4: Open गर्नुहोस्
```

================================================================================
PART 5: USER TRAINING (प्रयोगकर्ता तालिम)
================================================================================

## 5.1 Daily Workflow (दैनिक काम)

```
Morning (बिहान):
┌────────────────────────────────────────┐
│ 1. App खोल्नुहोस्                      │
│ 2. Dashboard मा आजको स्टक हेर्नुहोस्   │
│ 3. कम स्टक भएको मासु किन्नुहोस्      │
│ 4. Purchase entry गर्नुहोस्            │
└────────────────────────────────────────┘

Throughout Day (दिनभरि):
┌────────────────────────────────────────┐
│ 1. हरेक बिक्री record गर्नुहोस्        │
│ 2. उधारो दिएमा customer add गर्नुहोस् │
│ 3. बर्बादी भएमा log गर्नुहोस्         │
│ 4. खर्च भएमा entry गर्नुहोस्          │
└────────────────────────────────────────┘

Evening (बेलुका):
┌────────────────────────────────────────┐
│ 1. Reports हेर्नुहोस्                  │
│ 2. आजको नाफा/घाटा हेर्नुहोस्          │
│ 3. उधारो collection plan बनाउनुहोस्   │
└────────────────────────────────────────┘
```

## 5.2 Data Backup (डाटा ब्याकअप)

```bash
# Method 1: Manual Export
# Settings > Export Data > Share via WhatsApp/Email

# Method 2: Auto Backup (Future)
# Cloud sync with Supabase
# Daily automatic backup

# Method 3: Database File Copy
# Phone storage > Android > data > com.meatshop.app > databases
# meat_shop.db file copy गर्नुहोस्
```

================================================================================
PART 6: TROUBLESHOOTING (समस्या समाधान)
================================================================================

## Common Issues:

| Problem | Cause | Solution |
|---------|-------|----------|
| App crashes | Low memory | Phone restart गर्नुहोस् |
| Data lost | App uninstalled | Regular backup गर्नुहोस् |
| Wrong total | Wrong rate | Sale edit गर्नुहोस् |
| Stock wrong | Missing entry | Manual adjust गर्नुहोस् |
| Sync failed | No internet | Internet check गर्नुहोस् |
| Language issue | Locale bug | App restart गर्नुहोस् |

## Contact Support:
```
📧 Email: support@meatshop.app
📱 Phone: +977-98XXXXXXXX
💬 WhatsApp: +977-98XXXXXXXX
🌐 Website: www.meatshop.app
```

================================================================================
END OF GUIDE
================================================================================
